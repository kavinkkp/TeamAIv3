=== Business Solution ===
Contributors: wpbusinessthemes
Requires at least: 4.9
Version: 1.1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags: one-column, two-columns, left-sidebar, right-sidebar, custom-background, custom-colors, custom-header, custom-menu, featured-images, flexible-header, microformats, post-formats, rtl-language-support, sticky-post, threaded-comments, translation-ready, blog, e-commerce, theme-options

== Description ==

Business Solution is a fully customizable theme, which You can use to develop any business site, blog, portfolio, online store, storefront and eCommerce websites. You can sell beautifully with WooCommerce plugin. The theme uses bootstrap framework and responsive design will render very well on any viewing devices. You can use header image and hero content to highlight your business details. More details: https://wpfreetheme.space/product/wordpress-business-solution-theme/

== Installation ==

1. In your admin panel, go to Appearance -> Themes and click the 'Add New' button.
2. Type in Business Solution in the search form and press the 'Enter' key on your keyboard.
3. Click on the 'Activate' button to use your new theme right away.
4. Navigate to Appearance > Customize -> Theme Options in your admin panel
6. Add contact details
7. Select Product Navigation, Product slider from Appearance > Customize > Theme Options
8. Navigate to Appearance > Customize -> Header image -> Change header background
9. Navigate to Appearance > Customize -> Theme Options -> Header Select top banner, Hero content, Header text color. 

== Copyright ==

Business Solution WordPress Theme, Copyright 2019 www.wpfreetheme.space
Business Solution is distributed under the terms of the GNU GPL

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

Business Solution Theme bundles the following third-party resources:

* HTML5 Shiv v3.7.0, Copyright 2014 Alexander Farkas
* Licenses: MIT/GPL2
* Source: https://github.com/aFarkas/html5shiv

* Font Awesome (c) Dave Gandy, OFL, MIT
* License: SIL Open Font License, version 4.7
* Source: http://fontawesome.io/

* Bootstrap CSS
* Copyright 2011-2015 Twitter, Inc.
* Licensed under MIT and GPL license (https://github.com/twbs/bootstrap/blob/master/LICENSE)
* Source:http://getbootstrap.com

* Bootstrap js
* Copyright 2011-2015 Twitter, Inc.
* Licensed under MIT and GPL license :http://opensource.org/licenses/MIT
* Source:http://getbootstrap.com

* Alpha Color Picker Customizer Control (c) Cristian-Ungureanu, GNU GPL
* Licenses: GNU General Public License 
* Source:https://github.com/Codeinwp/customizer-controls/blob/master/customizer-alpha-color-picker/

* Navigation CSS styles, navigation.js - https://github.com/WordPress/twentysixteen 
* (C) 2016 WordPress.org, [GNU GPL, version 2 or later ( http://www.gnu.org/licenses/old-licenses/gpl-2.0.html )

* keyboard-image-navigation.js - https://github.com/WordPress/twentysixteen 
* (C) 2016 WordPress.org, [GNU GPL, version 2 or later ( http://www.gnu.org/licenses/old-licenses/gpl-2.0.html )

* @package   TGM-Plugin-Activation
* @version   2.6.1 for parent theme Business Solution for publication on WordPress.org
* @link      http://tgmpluginactivation.com/
* @author    Thomas Griffin, Gary Jones, Juliette Reinders Folmer
* @copyright Copyright (c) 2011, Thomas Griffin
* @license   GPL-2.0+

Image used in screenshot & default header : 

* Image for theme screenshot, Copyright https://pxhere.com 
* License: CC0 1.0 Universal (CC0 1.0)
* Source: https://pxhere.com/en/photo/1282006

== Changelog ==

= 1.0.9 =

* Added new css to blog layout. 
* Fixed css issues.

= 1.0.8 =

* Added demo content link to theme home page and updated in admin the notice.
* Header default colour css issues
* Fixed sticky menu issues
* Set the WooCommerce sidebar layout to left

= 1.0 =

* Initial version

