<?php
/**
 * Index file
 *
 * @package     Xolo
 * @author      Xolo Software
 * @since       1.0.0
 */

/* Silence is golden, and we agree. */
